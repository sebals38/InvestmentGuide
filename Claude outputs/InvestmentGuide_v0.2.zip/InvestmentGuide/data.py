"""
data.py — 시장 데이터 수집·캐시 (Yahoo Finance + FRED)

- 매일 전체 기간을 다시 받아 data/market.csv 에 저장 → 저장소에 커밋되므로
  Yahoo 가 막히거나 데이터가 바뀌어도 그날의 원천이 남습니다 (백테스트 재현용).
- 수집 실패 시 캐시로 대체하고 경고를 출력합니다.
- --demo: 네트워크 없이 합성 데이터 (위기 구간 포함) 로 레이아웃·로직 점검.
"""
from __future__ import annotations

import datetime as dt
import io
import os
import sys

import numpy as np
import pandas as pd
import requests

HERE = os.path.dirname(os.path.abspath(__file__))

FRED_CSV = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={sid}"


def _p(path: str) -> str:
    return path if os.path.isabs(path) else os.path.join(HERE, path)


# ─────────────────────────── 원천 수집 ───────────────────────────
def fetch_yahoo(tickers: dict, start: str) -> pd.DataFrame:
    import yfinance as yf

    symbols = list(tickers.values())
    raw = yf.download(symbols, start=start, auto_adjust=False, progress=False, group_by="column", threads=True)
    if raw.empty:
        raise RuntimeError("Yahoo Finance 응답이 비어 있음")
    close = raw["Close"] if isinstance(raw.columns, pd.MultiIndex) else raw[["Close"]]
    if isinstance(close, pd.Series):
        close = close.to_frame(symbols[0])
    inv = {v: k for k, v in tickers.items()}
    close = close.rename(columns=inv)
    close.index = pd.to_datetime(close.index).tz_localize(None)
    return close


def fetch_fred(series: dict, start: str) -> pd.DataFrame:
    out = {}
    for key, sid in series.items():
        r = requests.get(FRED_CSV.format(sid=sid), timeout=30)
        r.raise_for_status()
        df = pd.read_csv(io.StringIO(r.text))
        df.columns = ["date", key]
        df["date"] = pd.to_datetime(df["date"])
        df[key] = pd.to_numeric(df[key], errors="coerce")  # FRED 는 결측을 '.' 로 표기
        out[key] = df.set_index("date")[key]
    df = pd.DataFrame(out)
    return df[df.index >= pd.Timestamp(start)]


def fetch_market(cfg: dict) -> pd.DataFrame:
    src = cfg["sources"]
    start = src["start"]
    y = fetch_yahoo(src["yahoo"], start)
    f = fetch_fred(src["fred"], start)
    m = y.join(f, how="outer").sort_index()
    # 미국 거래일 기준으로 정렬: S&P500 이 있는 날만 남기고 나머지는 앞값 채움
    m = m[m["spx"].notna()]
    m = m.ffill()
    return m


# ─────────────────────────── 캐시 ───────────────────────────
def load_market(cfg: dict, demo: bool = False, refresh: bool = True) -> tuple[pd.DataFrame, str]:
    """(DataFrame, 출처 문자열). 출처는 'live' | 'cache' | 'demo'."""
    if demo:
        return demo_market(), "demo"

    cache = _p(cfg["output"]["market_cache"])
    if refresh:
        try:
            m = fetch_market(cfg)
            os.makedirs(os.path.dirname(cache), exist_ok=True)
            m.to_csv(cache, float_format="%.4f")
            return m, "live"
        except Exception as e:  # noqa: BLE001
            print(f"[경고] 실시간 수집 실패 → 캐시 사용: {e}", file=sys.stderr)

    if os.path.exists(cache):
        m = pd.read_csv(cache, index_col=0, parse_dates=True)
        return m, "cache"
    raise RuntimeError("실시간 수집도 실패했고 캐시(data/market.csv)도 없습니다.")


# ─────────────────────────── 데모 ───────────────────────────
def demo_market(days: int = 3000, seed: int = 7) -> pd.DataFrame:
    """위기 두 번(급락·완만한 약세)을 심어 둔 합성 데이터. 국면이 실제로 바뀌는지 보는 용도."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range(end=dt.date.today(), periods=days)
    n = len(idx)

    # 일별 변동성 경로: 평소 0.8%, 위기 구간에서 3~4%
    vol = np.full(n, 0.008)
    drift = np.full(n, 0.0004)
    crash1 = slice(int(n * 0.35), int(n * 0.35) + 45)     # 급락 (코로나형)
    bear2 = slice(int(n * 0.70), int(n * 0.70) + 200)     # 완만한 약세 (2022형)
    vol[crash1] = 0.04
    drift[crash1] = -0.012
    vol[bear2] = 0.016
    drift[bear2] = -0.0012
    rets = rng.normal(drift, vol)
    spx = 2000 * np.exp(np.cumsum(rets))

    rv = pd.Series(rets).rolling(10).std().bfill().to_numpy()
    vix = np.clip(11 + 900 * rv + rng.normal(0, 1.2, n), 9, 85)
    hy = np.clip(3.3 + 250 * rv + rng.normal(0, 0.08, n), 2.5, 20)
    move = np.clip(70 + 3000 * rv + rng.normal(0, 4, n), 45, 200)

    kospi = 2500 * np.exp(np.cumsum(rets * 1.1 + rng.normal(0, 0.006, n)))
    usdkrw = 1250 * np.exp(np.cumsum(-rets * 0.4 + rng.normal(0, 0.003, n)))
    ndx = spx * 8 * np.exp(np.cumsum(rng.normal(0, 0.004, n)))
    kosdaq = kospi * 0.3 * np.exp(np.cumsum(rng.normal(0, 0.006, n)))
    tnx = np.clip(3.5 + np.cumsum(rng.normal(0, 0.03, n)) * 0.2, 0.5, 8)
    dxy = 100 * np.exp(np.cumsum(rng.normal(0, 0.003, n)))
    gold = 2000 * np.exp(np.cumsum(rng.normal(0.0002, 0.009, n)))
    oil = 75 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))

    return pd.DataFrame({
        "spx": spx, "ndx": ndx, "vix": vix, "move": move, "hy": hy,
        "kospi": kospi, "kosdaq": kosdaq, "usdkrw": usdkrw,
        "tnx": tnx, "dxy": dxy, "gold": gold, "oil": oil,
    }, index=idx)
