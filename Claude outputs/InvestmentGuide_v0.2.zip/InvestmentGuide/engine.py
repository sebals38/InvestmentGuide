"""
engine.py — 국면 판정 엔진 v0.2 (순수 계산, 네트워크 없음)

입력:  시장 DataFrame (index=날짜, columns: spx, vix, hy, kospi, usdkrw, [move ...])
출력:  날짜별 온도계 점수·국면·목표 노출이 담긴 DataFrame

dashboard.py(오늘 판정)와 backtest.py(과거 전체)가 같은 함수를 씁니다.
→ 대시보드가 보여주는 숫자와 백테스트가 검증한 숫자가 항상 같습니다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

REGIMES = ["overheated", "uptrend", "shock", "stabilized"]
REGIME_KO = {
    "overheated": "과열 상승",
    "uptrend": "일반 상승",
    "shock": "충격 진행",
    "stabilized": "안정화 침체",
}
REGIME_COLOR = {
    "overheated": "#d97706",
    "uptrend": "#16a34a",
    "shock": "#dc2626",
    "stabilized": "#2563eb",
}


# ─────────────────────────── 1. 피처 ───────────────────────────
def build_features(m: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """온도계·안정화 조건·국내 조정에 필요한 파생값을 모두 계산한다."""
    rg = cfg["regime"]
    th = cfg["thermometers"]
    kr = cfg["korea"]
    sm = int(rg["smoothing_days"])

    f = pd.DataFrame(index=m.index)

    # 온도계 1: 추세 (S&P500 vs 200일선)
    ma = int(th["trend"]["ma_days"])
    f["spx"] = m["spx"]
    f["spx_ma200"] = m["spx"].rolling(ma).mean()
    f["spx_dist"] = m["spx"] / f["spx_ma200"] - 1.0
    f["spx_dist_s"] = f["spx_dist"].rolling(sm).mean()
    f["t_trend"] = (f["spx_dist"] < 0).astype(float)

    # 온도계 2: 공포 (VIX)
    f["vix"] = m["vix"]
    f["vix_ma20"] = m["vix"].rolling(20).mean()
    f["t_fear"] = (m["vix"] >= float(th["fear"]["threshold"])).astype(float)

    # 온도계 3: 신용 (하이일드 스프레드, FRED 는 결측이 있으므로 ffill)
    hy = m["hy"].ffill()
    f["hy"] = hy
    f["hy_ma20"] = hy.rolling(20).mean()
    f["t_credit"] = (hy >= float(th["credit"]["threshold"])).astype(float)

    # 점수 0~3 과 5일 스무딩
    f["score_raw"] = f["t_trend"] + f["t_fear"] + f["t_credit"]
    f["score_s"] = f["score_raw"].rolling(sm).mean()

    # 안정화 조건 3개
    f["c_vix_below_25"] = (m["vix"] < float(th["fear"]["threshold"])).astype(float)
    calm = rg.get("calm_override", {})
    vix_calm = float(calm.get("vix", 0))
    hy_calm = float(calm.get("hy", 0))
    f["c_vix_falling"] = ((m["vix"] < f["vix_ma20"]) | (m["vix"] < vix_calm)).astype(float)
    f["c_hy_narrowing"] = ((hy < f["hy_ma20"]) | (hy < hy_calm)).astype(float)
    f["stab_raw"] = f["c_vix_below_25"] + f["c_vix_falling"] + f["c_hy_narrowing"]
    f["stab_s"] = f["stab_raw"].rolling(sm).mean()
    f["stab_n"] = f["stab_s"].round().clip(0, 3)  # 5일 평균을 반올림한 "확인된 조건 개수"

    # 국내: KOSPI 200일선, 환율
    if "kospi" in m:
        kma = int(kr["kospi_ma_days"])
        f["kospi"] = m["kospi"]
        f["kospi_ma200"] = m["kospi"].rolling(kma).mean()
        f["kospi_dist"] = m["kospi"] / f["kospi_ma200"] - 1.0
        f["kospi_dist_s"] = f["kospi_dist"].rolling(sm).mean()
        f["kr_below_ma"] = (f["kospi_dist_s"] < 0).astype(float)
        f["kr_overheat"] = (f["kospi_dist_s"] >= float(kr["overheat_pct"]) / 100).astype(float)
    else:
        f["kr_below_ma"] = 0.0
        f["kr_overheat"] = 0.0

    if "usdkrw" in m:
        fx = kr["fx"]
        d = int(fx["change_days"])
        f["usdkrw"] = m["usdkrw"]
        f["fx_chg"] = m["usdkrw"].pct_change(d)
        fx_ma = m["usdkrw"].rolling(200).mean()
        f["fx_warn"] = ((f["fx_chg"] >= float(fx["warn_change_pct"]) / 100) & (m["usdkrw"] > fx_ma)).astype(float)
    else:
        f["fx_warn"] = 0.0

    # 보조: MOVE
    aux = cfg["auxiliary"]
    if "move" in m:
        f["move"] = m["move"].ffill()
        f["move_warn"] = (f["move"] >= float(aux["move_warn"])).astype(float)
        f["move_extreme"] = (f["move"] >= float(aux["move_extreme"])).astype(float)
    else:
        f["move"] = np.nan
        f["move_warn"] = 0.0
        f["move_extreme"] = 0.0

    return f


# ─────────────────────────── 2. 국면 상태기계 ───────────────────────────
def run_regime(f: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """피처 → 날짜별 국면·노출. 상태(이전 국면, 사다리 일수)가 있어서 루프로 돈다."""
    rg = cfg["regime"]
    ex = cfg["exposure"]
    kr = cfg["korea"]

    shock_score = float(rg["shock_score"])
    vix_imm = float(rg["shock_vix_immediate"])
    oh_in = float(rg["overheat_in_pct"]) / 100
    oh_out = float(rg["overheat_out_pct"]) / 100
    ret_score = float(rg["uptrend_return_score"])
    step = float(rg["ladder_step_pct"])
    days_per_step = int(rg["ladder_days_per_step"])
    cut = float(ex["uptrend_warning_cut_pct"])

    valid = f["score_s"].notna() & f["spx_dist_s"].notna() & f["stab_s"].notna()
    idx = f.index[valid]

    regimes, exposures, ladder_days, ladder_steps = [], [], [], []
    state = None
    days_all = 0  # 안정화 조건 3개가 모두 유지된 연속 일수

    for d in idx:
        r = f.loc[d]
        score_s, dist_s, vix, stab_n = r["score_s"], r["spx_dist_s"], r["vix"], int(r["stab_n"])

        # 초기 상태
        if state is None:
            if score_s >= shock_score:
                state = "shock"
            elif dist_s >= oh_in:
                state = "overheated"
            elif dist_s >= 0:
                state = "uptrend"
            else:
                state = "stabilized"

        # (1) 충격 트리거는 어느 국면에서든 최우선
        if vix > vix_imm or score_s >= shock_score:
            new = "shock"
        elif state == "shock":
            new = "stabilized" if stab_n == 3 else "shock"
        elif state == "stabilized":
            new = "uptrend" if (score_s < ret_score and dist_s > 0) else "stabilized"
        elif state == "overheated":
            new = "uptrend" if dist_s < oh_out else "overheated"
        else:  # uptrend
            new = "overheated" if dist_s >= oh_in else "uptrend"

        # (2) 사다리 일수 갱신 (충격·안정화 국면에서만 의미)
        if new in ("shock", "stabilized"):
            if stab_n == 3:
                days_all += 1
            else:
                days_all = max(0, days_all - days_per_step)  # 신호가 꺼지면 한 계단 되돌림
        else:
            days_all = 0

        # (3) 목표 노출
        if new == "overheated":
            expo = float(ex["overheated"])
            lstep = 0
        elif new == "uptrend":
            warn = int(round(score_s))
            expo = max(float(ex["uptrend"]) - cut * warn, float(ex["shock"]))
            lstep = 0
        elif new == "shock":
            # 충격 상한 30 + 확인된 안정화 조건 1개당 +5 (3개 모두 확인되면 다음날 '안정화'로 전환)
            expo = float(ex["shock"]) + step * stab_n
            lstep = stab_n
        else:  # stabilized
            lstep = stab_n + days_all // days_per_step
            expo = min(float(ex["shock"]) + step * lstep, float(ex["stabilized_max"]))

        regimes.append(new)
        exposures.append(expo)
        ladder_days.append(days_all)
        ladder_steps.append(lstep)
        state = new

    out = f.loc[idx].copy()
    out["regime"] = regimes
    out["exposure_us"] = exposures
    out["ladder_days"] = ladder_days
    out["ladder_step"] = ladder_steps

    # 국내 노출: 국면은 미국이 정하고 KOSPI 가 조정
    kr_expo = out["exposure_us"].copy()
    kr_expo = kr_expo - float(kr["below_ma_penalty_pct"]) * out["kr_below_ma"]
    kr_expo = kr_expo - float(kr["fx"]["penalty_pct"]) * out["fx_warn"]
    kr_expo = np.where(out["kr_overheat"] == 1, np.minimum(kr_expo, float(ex["overheated"])), kr_expo)
    out["exposure_kr"] = np.clip(kr_expo, 10, 100)

    out["trading_bucket"] = np.where(out["regime"] == "shock",
                                     float(ex["trading_bucket"]["shock"]),
                                     float(ex["trading_bucket"]["normal"]))
    return out


def run(m: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    return run_regime(build_features(m, cfg), cfg)


# ─────────────────────────── 3. 오늘 스냅샷 (대시보드용) ───────────────────────────
def snapshot(res: pd.DataFrame, cfg: dict) -> dict:
    """마지막 날의 판정을 사람이 읽을 수 있는 dict 로."""
    r = res.iloc[-1]
    th = cfg["thermometers"]
    prev = res.iloc[-2] if len(res) > 1 else r

    def flag(v):
        return bool(v == 1)

    return {
        "date": res.index[-1].strftime("%Y-%m-%d"),
        "regime": r["regime"],
        "regime_ko": REGIME_KO[r["regime"]],
        "regime_prev": prev["regime"],
        "exposure_us": float(r["exposure_us"]),
        "exposure_kr": float(r["exposure_kr"]),
        "trading_bucket": float(r["trading_bucket"]),
        "score_raw": int(r["score_raw"]),
        "score_s": float(r["score_s"]),
        "thermometers": [
            {"id": "trend", "name": "추세", "desc": "S&P500 vs 200일선",
             "value": f"{r['spx_dist'] * 100:+.1f}%", "rule": th["trend"]["rule"], "on": flag(r["t_trend"])},
            {"id": "fear", "name": "공포", "desc": "VIX",
             "value": f"{r['vix']:.1f}", "rule": th["fear"]["rule"], "on": flag(r["t_fear"])},
            {"id": "credit", "name": "신용", "desc": "하이일드 스프레드",
             "value": f"{r['hy']:.2f}%p", "rule": th["credit"]["rule"], "on": flag(r["t_credit"])},
        ],
        "stabilization": [
            {"id": "vix_below_25", "rule": "VIX < 25", "ok": flag(r["c_vix_below_25"])},
            {"id": "vix_falling", "rule": "VIX < 20일 평균", "ok": flag(r["c_vix_falling"]),
             "detail": f"{r['vix']:.1f} vs {r['vix_ma20']:.1f}"},
            {"id": "hy_narrowing", "rule": "HY 스프레드 축소 중", "ok": flag(r["c_hy_narrowing"]),
             "detail": f"{r['hy']:.2f} vs {r['hy_ma20']:.2f}"},
        ],
        "stab_n": int(r["stab_n"]),
        "ladder_days": int(r["ladder_days"]),
        "ladder_step": int(r["ladder_step"]),
        "overheat_dist": float(r["spx_dist_s"]),
        "kr": {
            "kospi_dist": float(r["kospi_dist"]) if "kospi_dist" in r and pd.notna(r["kospi_dist"]) else None,
            "below_ma": flag(r["kr_below_ma"]),
            "overheat": flag(r["kr_overheat"]),
            "fx_chg": float(r["fx_chg"]) if "fx_chg" in r and pd.notna(r["fx_chg"]) else None,
            "fx_warn": flag(r["fx_warn"]),
        },
        "aux": {
            "move": float(r["move"]) if pd.notna(r["move"]) else None,
            "move_warn": flag(r["move_warn"]),
            "move_extreme": flag(r["move_extreme"]),
        },
    }
